// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'cc_note.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#adding-getters-and-methods-to-our-models');

CCNote _$CCNoteFromJson(Map<String, dynamic> json) {
  return _CCNote.fromJson(json);
}

/// @nodoc
mixin _$CCNote {
  int get id => throw _privateConstructorUsedError;
  double? get note => throw _privateConstructorUsedError;
  bool? get absent => throw _privateConstructorUsedError;
  String get llPeriode => throw _privateConstructorUsedError;
  String get llPeriodeAr => throw _privateConstructorUsedError;
  String get apCode => throw _privateConstructorUsedError;
  String get rattachementMcMcLibelleFr => throw _privateConstructorUsedError;
  String get rattachementMcMcLibelleAr => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $CCNoteCopyWith<CCNote> get copyWith => throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $CCNoteCopyWith<$Res> {
  factory $CCNoteCopyWith(CCNote value, $Res Function(CCNote) then) =
      _$CCNoteCopyWithImpl<$Res, CCNote>;
  @useResult
  $Res call(
      {int id,
      double? note,
      bool? absent,
      String llPeriode,
      String llPeriodeAr,
      String apCode,
      String rattachementMcMcLibelleFr,
      String rattachementMcMcLibelleAr});
}

/// @nodoc
class _$CCNoteCopyWithImpl<$Res, $Val extends CCNote>
    implements $CCNoteCopyWith<$Res> {
  _$CCNoteCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? id = null,
    Object? note = freezed,
    Object? absent = freezed,
    Object? llPeriode = null,
    Object? llPeriodeAr = null,
    Object? apCode = null,
    Object? rattachementMcMcLibelleFr = null,
    Object? rattachementMcMcLibelleAr = null,
  }) {
    return _then(_value.copyWith(
      id: null == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as int,
      note: freezed == note
          ? _value.note
          : note // ignore: cast_nullable_to_non_nullable
              as double?,
      absent: freezed == absent
          ? _value.absent
          : absent // ignore: cast_nullable_to_non_nullable
              as bool?,
      llPeriode: null == llPeriode
          ? _value.llPeriode
          : llPeriode // ignore: cast_nullable_to_non_nullable
              as String,
      llPeriodeAr: null == llPeriodeAr
          ? _value.llPeriodeAr
          : llPeriodeAr // ignore: cast_nullable_to_non_nullable
              as String,
      apCode: null == apCode
          ? _value.apCode
          : apCode // ignore: cast_nullable_to_non_nullable
              as String,
      rattachementMcMcLibelleFr: null == rattachementMcMcLibelleFr
          ? _value.rattachementMcMcLibelleFr
          : rattachementMcMcLibelleFr // ignore: cast_nullable_to_non_nullable
              as String,
      rattachementMcMcLibelleAr: null == rattachementMcMcLibelleAr
          ? _value.rattachementMcMcLibelleAr
          : rattachementMcMcLibelleAr // ignore: cast_nullable_to_non_nullable
              as String,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$CCNoteImplCopyWith<$Res> implements $CCNoteCopyWith<$Res> {
  factory _$$CCNoteImplCopyWith(
          _$CCNoteImpl value, $Res Function(_$CCNoteImpl) then) =
      __$$CCNoteImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {int id,
      double? note,
      bool? absent,
      String llPeriode,
      String llPeriodeAr,
      String apCode,
      String rattachementMcMcLibelleFr,
      String rattachementMcMcLibelleAr});
}

/// @nodoc
class __$$CCNoteImplCopyWithImpl<$Res>
    extends _$CCNoteCopyWithImpl<$Res, _$CCNoteImpl>
    implements _$$CCNoteImplCopyWith<$Res> {
  __$$CCNoteImplCopyWithImpl(
      _$CCNoteImpl _value, $Res Function(_$CCNoteImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? id = null,
    Object? note = freezed,
    Object? absent = freezed,
    Object? llPeriode = null,
    Object? llPeriodeAr = null,
    Object? apCode = null,
    Object? rattachementMcMcLibelleFr = null,
    Object? rattachementMcMcLibelleAr = null,
  }) {
    return _then(_$CCNoteImpl(
      id: null == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as int,
      note: freezed == note
          ? _value.note
          : note // ignore: cast_nullable_to_non_nullable
              as double?,
      absent: freezed == absent
          ? _value.absent
          : absent // ignore: cast_nullable_to_non_nullable
              as bool?,
      llPeriode: null == llPeriode
          ? _value.llPeriode
          : llPeriode // ignore: cast_nullable_to_non_nullable
              as String,
      llPeriodeAr: null == llPeriodeAr
          ? _value.llPeriodeAr
          : llPeriodeAr // ignore: cast_nullable_to_non_nullable
              as String,
      apCode: null == apCode
          ? _value.apCode
          : apCode // ignore: cast_nullable_to_non_nullable
              as String,
      rattachementMcMcLibelleFr: null == rattachementMcMcLibelleFr
          ? _value.rattachementMcMcLibelleFr
          : rattachementMcMcLibelleFr // ignore: cast_nullable_to_non_nullable
              as String,
      rattachementMcMcLibelleAr: null == rattachementMcMcLibelleAr
          ? _value.rattachementMcMcLibelleAr
          : rattachementMcMcLibelleAr // ignore: cast_nullable_to_non_nullable
              as String,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$CCNoteImpl extends _CCNote {
  const _$CCNoteImpl(
      {required this.id,
      this.note,
      this.absent,
      required this.llPeriode,
      required this.llPeriodeAr,
      required this.apCode,
      required this.rattachementMcMcLibelleFr,
      required this.rattachementMcMcLibelleAr})
      : super._();

  factory _$CCNoteImpl.fromJson(Map<String, dynamic> json) =>
      _$$CCNoteImplFromJson(json);

  @override
  final int id;
  @override
  final double? note;
  @override
  final bool? absent;
  @override
  final String llPeriode;
  @override
  final String llPeriodeAr;
  @override
  final String apCode;
  @override
  final String rattachementMcMcLibelleFr;
  @override
  final String rattachementMcMcLibelleAr;

  @override
  String toString() {
    return 'CCNote(id: $id, note: $note, absent: $absent, llPeriode: $llPeriode, llPeriodeAr: $llPeriodeAr, apCode: $apCode, rattachementMcMcLibelleFr: $rattachementMcMcLibelleFr, rattachementMcMcLibelleAr: $rattachementMcMcLibelleAr)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$CCNoteImpl &&
            (identical(other.id, id) || other.id == id) &&
            (identical(other.note, note) || other.note == note) &&
            (identical(other.absent, absent) || other.absent == absent) &&
            (identical(other.llPeriode, llPeriode) ||
                other.llPeriode == llPeriode) &&
            (identical(other.llPeriodeAr, llPeriodeAr) ||
                other.llPeriodeAr == llPeriodeAr) &&
            (identical(other.apCode, apCode) || other.apCode == apCode) &&
            (identical(other.rattachementMcMcLibelleFr,
                    rattachementMcMcLibelleFr) ||
                other.rattachementMcMcLibelleFr == rattachementMcMcLibelleFr) &&
            (identical(other.rattachementMcMcLibelleAr,
                    rattachementMcMcLibelleAr) ||
                other.rattachementMcMcLibelleAr == rattachementMcMcLibelleAr));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode => Object.hash(
      runtimeType,
      id,
      note,
      absent,
      llPeriode,
      llPeriodeAr,
      apCode,
      rattachementMcMcLibelleFr,
      rattachementMcMcLibelleAr);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$CCNoteImplCopyWith<_$CCNoteImpl> get copyWith =>
      __$$CCNoteImplCopyWithImpl<_$CCNoteImpl>(this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$CCNoteImplToJson(
      this,
    );
  }
}

abstract class _CCNote extends CCNote {
  const factory _CCNote(
      {required final int id,
      final double? note,
      final bool? absent,
      required final String llPeriode,
      required final String llPeriodeAr,
      required final String apCode,
      required final String rattachementMcMcLibelleFr,
      required final String rattachementMcMcLibelleAr}) = _$CCNoteImpl;
  const _CCNote._() : super._();

  factory _CCNote.fromJson(Map<String, dynamic> json) = _$CCNoteImpl.fromJson;

  @override
  int get id;
  @override
  double? get note;
  @override
  bool? get absent;
  @override
  String get llPeriode;
  @override
  String get llPeriodeAr;
  @override
  String get apCode;
  @override
  String get rattachementMcMcLibelleFr;
  @override
  String get rattachementMcMcLibelleAr;
  @override
  @JsonKey(ignore: true)
  _$$CCNoteImplCopyWith<_$CCNoteImpl> get copyWith =>
      throw _privateConstructorUsedError;
}
